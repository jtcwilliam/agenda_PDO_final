<?php

require_once 'classes/LDAP.class.php';

$ldap = new LDAP();

$usuario = $ldap->logar('nome_usuario_rede', 'senha');

echo "<pre>";
print_r($usuario);

?>

